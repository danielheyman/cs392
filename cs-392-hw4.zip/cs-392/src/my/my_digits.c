#include "my.h"

void my_digits() {
    char c = '0';
    while(c <= '9') my_char(c++);
}
