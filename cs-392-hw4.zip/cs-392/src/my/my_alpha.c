#include "my.h"

void my_alpha() {
    char c = 'A';
    while(c <= 'Z') my_char(c++);
}
