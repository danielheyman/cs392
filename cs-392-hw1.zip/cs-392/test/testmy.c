/* Test file

Daniel Heyman
I pledge my honor that I have abided by the Stevens Honor System.

*/ 
#include "my.h"

int main(int argc, char **argv) {
    my_str("my_char tests:\n");
    my_char('F');
    
    my_str("\n\nmy_str tests:\n");
    my_str("");
    my_str(NULL);
    
    my_str("\nmy_int tests:\n");
    my_int(0);
    my_int(500);
    my_int(-500);
    my_int(2147483647);
    my_int(-2147483648);
    
    my_str("\n\nmy_num_base tests:\n");
    my_num_base(9, "RTFM");
    my_num_base(22, "RTFM");
    my_num_base(22, "");
    my_num_base(-22, "RTFM");
    my_num_base(2147483647, "RTFM");
    my_num_base(-2147483648, "RTFM");
    
    my_str("\n\nmy_alpha tests:\n");
    my_alpha();
    
    my_str("\n\nmy_digits tests:\n");
    my_digits();
    
    my_str("\n\nmy_strindex tests:\n");
    my_int(my_strindex("", 'o'));
    my_int(my_strindex("hello", 'l'));
    my_int(my_strindex("hello", 'g'));
    
    my_str("\n\nmy_strrindex tests:\n");
    my_int(my_strrindex("", 'o'));
    my_int(my_strrindex("hello", 'l'));
    my_int(my_strrindex("hello", 'g'));
    
    my_str("\n\nmy_strlen tests:\n");
    my_int(my_strlen(NULL));
    my_int(my_strlen(""));
    my_int(my_strlen("hello"));
    
    my_str("\n\nmy_revstr tests:\n");
    my_int(my_revstr(NULL));
    my_int(my_revstr(""));
    char s[] = "hello";
    my_int(my_revstr(s));
    my_str(s);
    
    return 0;
}
